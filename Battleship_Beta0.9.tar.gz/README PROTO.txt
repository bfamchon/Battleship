jeu � Battleship �


Le jeu est compos� de deux programmes : 
BattleShipSrv.out le serveur en mode console.
BayttleShip.out, le client en mode graphique

Le client est compos� de trois �crans :
Ecran de menu : pour se connecter au serveur en sp�cifiant le Pseudo et l�ip du serveur
Ecran d�attente : pour positionner les navires avec un radis pour valider et rentrer dans le jeu.
Ecran de jeu : pour jouer les coups en coup par coup

I- DEMARRER LE JEU

Ouvrir  un terminal 

Lancer le serveur par la commande  ./bin/Battleshipsvr.out

Sur 2 autre machines (ou le tout sur la m�me) lancer les clients BattleShip.out

Entrez les identifiants Pseudo et Adresse IP du serveur

Cliquer sur � connect �

Choisir ses bateaux de mani�re al�atoire ou les tourner en cliquant dessus (modifier la position n�est pas encore livrable)

Positionner ses bateaux (Pas encore livrable)

Attendre son adversaire

Connexion de l�adversaire

Commencer la partie jeu

Pour le moment pas livrable juste un aper�u des clicks (bug de position) 

II- TERMINER LE JEU

Cliquer siur la croix puis sur  �quitter � pour se d�connecter ou la croix
