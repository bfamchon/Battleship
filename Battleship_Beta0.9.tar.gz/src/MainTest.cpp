#define BOOST_TEST_MODULE MesTestsUnitaires
#include <boost/test/included/unit_test.hpp>

#include "Bateau_test.hpp"
#include "Flotte_test.hpp"
#include "Joueur_test.hpp"
