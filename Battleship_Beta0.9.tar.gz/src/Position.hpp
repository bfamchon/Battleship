#ifndef POSITION_HPP
#define POSITION_HPP

struct Position {
  int _x;
  int _y;
};

#endif
